/**
 * Parking.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.model;

public class Parking  implements java.io.Serializable {
    private java.lang.String faculty;

    private int id;

    private int slot_price;

    private int telephone;

    private java.lang.String vehicle_num;

    private java.lang.String vehicle_type;

    private int year;

    public Parking() {
    }

    public Parking(
           java.lang.String faculty,
           int id,
           int slot_price,
           int telephone,
           java.lang.String vehicle_num,
           java.lang.String vehicle_type,
           int year) {
           this.faculty = faculty;
           this.id = id;
           this.slot_price = slot_price;
           this.telephone = telephone;
           this.vehicle_num = vehicle_num;
           this.vehicle_type = vehicle_type;
           this.year = year;
    }


    /**
     * Gets the faculty value for this Parking.
     * 
     * @return faculty
     */
    public java.lang.String getFaculty() {
        return faculty;
    }


    /**
     * Sets the faculty value for this Parking.
     * 
     * @param faculty
     */
    public void setFaculty(java.lang.String faculty) {
        this.faculty = faculty;
    }


    /**
     * Gets the id value for this Parking.
     * 
     * @return id
     */
    public int getId() {
        return id;
    }


    /**
     * Sets the id value for this Parking.
     * 
     * @param id
     */
    public void setId(int id) {
        this.id = id;
    }


    /**
     * Gets the slot_price value for this Parking.
     * 
     * @return slot_price
     */
    public int getSlot_price() {
        return slot_price;
    }


    /**
     * Sets the slot_price value for this Parking.
     * 
     * @param slot_price
     */
    public void setSlot_price(int slot_price) {
        this.slot_price = slot_price;
    }


    /**
     * Gets the telephone value for this Parking.
     * 
     * @return telephone
     */
    public int getTelephone() {
        return telephone;
    }


    /**
     * Sets the telephone value for this Parking.
     * 
     * @param telephone
     */
    public void setTelephone(int telephone) {
        this.telephone = telephone;
    }


    /**
     * Gets the vehicle_num value for this Parking.
     * 
     * @return vehicle_num
     */
    public java.lang.String getVehicle_num() {
        return vehicle_num;
    }


    /**
     * Sets the vehicle_num value for this Parking.
     * 
     * @param vehicle_num
     */
    public void setVehicle_num(java.lang.String vehicle_num) {
        this.vehicle_num = vehicle_num;
    }


    /**
     * Gets the vehicle_type value for this Parking.
     * 
     * @return vehicle_type
     */
    public java.lang.String getVehicle_type() {
        return vehicle_type;
    }


    /**
     * Sets the vehicle_type value for this Parking.
     * 
     * @param vehicle_type
     */
    public void setVehicle_type(java.lang.String vehicle_type) {
        this.vehicle_type = vehicle_type;
    }


    /**
     * Gets the year value for this Parking.
     * 
     * @return year
     */
    public int getYear() {
        return year;
    }


    /**
     * Sets the year value for this Parking.
     * 
     * @param year
     */
    public void setYear(int year) {
        this.year = year;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Parking)) return false;
        Parking other = (Parking) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.faculty==null && other.getFaculty()==null) || 
             (this.faculty!=null &&
              this.faculty.equals(other.getFaculty()))) &&
            this.id == other.getId() &&
            this.slot_price == other.getSlot_price() &&
            this.telephone == other.getTelephone() &&
            ((this.vehicle_num==null && other.getVehicle_num()==null) || 
             (this.vehicle_num!=null &&
              this.vehicle_num.equals(other.getVehicle_num()))) &&
            ((this.vehicle_type==null && other.getVehicle_type()==null) || 
             (this.vehicle_type!=null &&
              this.vehicle_type.equals(other.getVehicle_type()))) &&
            this.year == other.getYear();
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getFaculty() != null) {
            _hashCode += getFaculty().hashCode();
        }
        _hashCode += getId();
        _hashCode += getSlot_price();
        _hashCode += getTelephone();
        if (getVehicle_num() != null) {
            _hashCode += getVehicle_num().hashCode();
        }
        if (getVehicle_type() != null) {
            _hashCode += getVehicle_type().hashCode();
        }
        _hashCode += getYear();
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Parking.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://model.com", "Parking"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("faculty");
        elemField.setXmlName(new javax.xml.namespace.QName("http://model.com", "faculty"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("id");
        elemField.setXmlName(new javax.xml.namespace.QName("http://model.com", "id"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("slot_price");
        elemField.setXmlName(new javax.xml.namespace.QName("http://model.com", "slot_price"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("telephone");
        elemField.setXmlName(new javax.xml.namespace.QName("http://model.com", "telephone"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("vehicle_num");
        elemField.setXmlName(new javax.xml.namespace.QName("http://model.com", "vehicle_num"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("vehicle_type");
        elemField.setXmlName(new javax.xml.namespace.QName("http://model.com", "vehicle_type"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(true);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("year");
        elemField.setXmlName(new javax.xml.namespace.QName("http://model.com", "year"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "int"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
