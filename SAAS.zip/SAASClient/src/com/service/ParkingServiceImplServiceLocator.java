/**
 * ParkingServiceImplServiceLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.service;

public class ParkingServiceImplServiceLocator extends org.apache.axis.client.Service implements com.service.ParkingServiceImplService {

    public ParkingServiceImplServiceLocator() {
    }


    public ParkingServiceImplServiceLocator(org.apache.axis.EngineConfiguration config) {
        super(config);
    }

    public ParkingServiceImplServiceLocator(java.lang.String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
        super(wsdlLoc, sName);
    }

    // Use to get a proxy class for ParkingServiceImpl
    private java.lang.String ParkingServiceImpl_address = "http://localhost:8080/SAAS/services/ParkingServiceImpl";

    public java.lang.String getParkingServiceImplAddress() {
        return ParkingServiceImpl_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String ParkingServiceImplWSDDServiceName = "ParkingServiceImpl";

    public java.lang.String getParkingServiceImplWSDDServiceName() {
        return ParkingServiceImplWSDDServiceName;
    }

    public void setParkingServiceImplWSDDServiceName(java.lang.String name) {
        ParkingServiceImplWSDDServiceName = name;
    }

    public com.service.ParkingServiceImpl getParkingServiceImpl() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(ParkingServiceImpl_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getParkingServiceImpl(endpoint);
    }

    public com.service.ParkingServiceImpl getParkingServiceImpl(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            com.service.ParkingServiceImplSoapBindingStub _stub = new com.service.ParkingServiceImplSoapBindingStub(portAddress, this);
            _stub.setPortName(getParkingServiceImplWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setParkingServiceImplEndpointAddress(java.lang.String address) {
        ParkingServiceImpl_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (com.service.ParkingServiceImpl.class.isAssignableFrom(serviceEndpointInterface)) {
                com.service.ParkingServiceImplSoapBindingStub _stub = new com.service.ParkingServiceImplSoapBindingStub(new java.net.URL(ParkingServiceImpl_address), this);
                _stub.setPortName(getParkingServiceImplWSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        java.lang.String inputPortName = portName.getLocalPart();
        if ("ParkingServiceImpl".equals(inputPortName)) {
            return getParkingServiceImpl();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("http://service.com", "ParkingServiceImplService");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("http://service.com", "ParkingServiceImpl"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(java.lang.String portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        
if ("ParkingServiceImpl".equals(portName)) {
            setParkingServiceImplEndpointAddress(address);
        }
        else 
{ // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}
