package com.service;

public class ParkingServiceImplProxy implements com.service.ParkingServiceImpl {
  private String _endpoint = null;
  private com.service.ParkingServiceImpl parkingServiceImpl = null;
  
  public ParkingServiceImplProxy() {
    _initParkingServiceImplProxy();
  }
  
  public ParkingServiceImplProxy(String endpoint) {
    _endpoint = endpoint;
    _initParkingServiceImplProxy();
  }
  
  private void _initParkingServiceImplProxy() {
    try {
      parkingServiceImpl = (new com.service.ParkingServiceImplServiceLocator()).getParkingServiceImpl();
      if (parkingServiceImpl != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)parkingServiceImpl)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)parkingServiceImpl)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (parkingServiceImpl != null)
      ((javax.xml.rpc.Stub)parkingServiceImpl)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.service.ParkingServiceImpl getParkingServiceImpl() {
    if (parkingServiceImpl == null)
      _initParkingServiceImplProxy();
    return parkingServiceImpl;
  }
  
  public boolean addParking(com.model.Parking parking) throws java.rmi.RemoteException{
    if (parkingServiceImpl == null)
      _initParkingServiceImplProxy();
    return parkingServiceImpl.addParking(parking);
  }
  
  public boolean deleteParking(int id) throws java.rmi.RemoteException{
    if (parkingServiceImpl == null)
      _initParkingServiceImplProxy();
    return parkingServiceImpl.deleteParking(id);
  }
  
  public com.model.Parking getParking(int id) throws java.rmi.RemoteException{
    if (parkingServiceImpl == null)
      _initParkingServiceImplProxy();
    return parkingServiceImpl.getParking(id);
  }
  
  public com.model.Parking[] getAllParkings() throws java.rmi.RemoteException{
    if (parkingServiceImpl == null)
      _initParkingServiceImplProxy();
    return parkingServiceImpl.getAllParkings();
  }
  
  
}