package com.service;

public class ServiceImplProxy implements com.service.ServiceImpl {
  private String _endpoint = null;
  private com.service.ServiceImpl serviceImpl = null;
  
  public ServiceImplProxy() {
    _initServiceImplProxy();
  }
  
  public ServiceImplProxy(String endpoint) {
    _endpoint = endpoint;
    _initServiceImplProxy();
  }
  
  private void _initServiceImplProxy() {
    try {
      serviceImpl = (new com.service.ServiceImplServiceLocator()).getServiceImpl();
      if (serviceImpl != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)serviceImpl)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)serviceImpl)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (serviceImpl != null)
      ((javax.xml.rpc.Stub)serviceImpl)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.service.ServiceImpl getServiceImpl() {
    if (serviceImpl == null)
      _initServiceImplProxy();
    return serviceImpl;
  }
  
  public com.model.Library getLibrary(int id) throws java.rmi.RemoteException{
    if (serviceImpl == null)
      _initServiceImplProxy();
    return serviceImpl.getLibrary(id);
  }
  
  public boolean addSubject(com.model.Subject subject) throws java.rmi.RemoteException{
    if (serviceImpl == null)
      _initServiceImplProxy();
    return serviceImpl.addSubject(subject);
  }
  
  public com.model.Subject[] getAllSubjects() throws java.rmi.RemoteException{
    if (serviceImpl == null)
      _initServiceImplProxy();
    return serviceImpl.getAllSubjects();
  }
  
  public boolean deleteSubject(int id) throws java.rmi.RemoteException{
    if (serviceImpl == null)
      _initServiceImplProxy();
    return serviceImpl.deleteSubject(id);
  }
  
  public com.model.Subject getSubject(int id) throws java.rmi.RemoteException{
    if (serviceImpl == null)
      _initServiceImplProxy();
    return serviceImpl.getSubject(id);
  }
  
  public boolean addLibrary(com.model.Library library) throws java.rmi.RemoteException{
    if (serviceImpl == null)
      _initServiceImplProxy();
    return serviceImpl.addLibrary(library);
  }
  
  public boolean deleteLibrary(int id) throws java.rmi.RemoteException{
    if (serviceImpl == null)
      _initServiceImplProxy();
    return serviceImpl.deleteLibrary(id);
  }
  
  public com.model.Library[] getAllLibraries() throws java.rmi.RemoteException{
    if (serviceImpl == null)
      _initServiceImplProxy();
    return serviceImpl.getAllLibraries();
  }
  
  public boolean addParking(com.model.Parking parking) throws java.rmi.RemoteException{
    if (serviceImpl == null)
      _initServiceImplProxy();
    return serviceImpl.addParking(parking);
  }
  
  public boolean deleteParking(int id) throws java.rmi.RemoteException{
    if (serviceImpl == null)
      _initServiceImplProxy();
    return serviceImpl.deleteParking(id);
  }
  
  public com.model.Parking getParking(int id) throws java.rmi.RemoteException{
    if (serviceImpl == null)
      _initServiceImplProxy();
    return serviceImpl.getParking(id);
  }
  
  public com.model.Parking[] getAllParkings() throws java.rmi.RemoteException{
    if (serviceImpl == null)
      _initServiceImplProxy();
    return serviceImpl.getAllParkings();
  }
  
  public com.model.Student getStudent(int id) throws java.rmi.RemoteException{
    if (serviceImpl == null)
      _initServiceImplProxy();
    return serviceImpl.getStudent(id);
  }
  
  public com.model.Student[] getAllStudents() throws java.rmi.RemoteException{
    if (serviceImpl == null)
      _initServiceImplProxy();
    return serviceImpl.getAllStudents();
  }
  
  public boolean addStudent(com.model.Student student) throws java.rmi.RemoteException{
    if (serviceImpl == null)
      _initServiceImplProxy();
    return serviceImpl.addStudent(student);
  }
  
  public boolean deleteStudent(int id) throws java.rmi.RemoteException{
    if (serviceImpl == null)
      _initServiceImplProxy();
    return serviceImpl.deleteStudent(id);
  }
  
  
}