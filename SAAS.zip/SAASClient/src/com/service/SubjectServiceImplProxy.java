package com.service;

public class SubjectServiceImplProxy implements com.service.SubjectServiceImpl {
  private String _endpoint = null;
  private com.service.SubjectServiceImpl subjectServiceImpl = null;
  
  public SubjectServiceImplProxy() {
    _initSubjectServiceImplProxy();
  }
  
  public SubjectServiceImplProxy(String endpoint) {
    _endpoint = endpoint;
    _initSubjectServiceImplProxy();
  }
  
  private void _initSubjectServiceImplProxy() {
    try {
      subjectServiceImpl = (new com.service.SubjectServiceImplServiceLocator()).getSubjectServiceImpl();
      if (subjectServiceImpl != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)subjectServiceImpl)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)subjectServiceImpl)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (subjectServiceImpl != null)
      ((javax.xml.rpc.Stub)subjectServiceImpl)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.service.SubjectServiceImpl getSubjectServiceImpl() {
    if (subjectServiceImpl == null)
      _initSubjectServiceImplProxy();
    return subjectServiceImpl;
  }
  
  public boolean addSubject(com.model.Subject subject) throws java.rmi.RemoteException{
    if (subjectServiceImpl == null)
      _initSubjectServiceImplProxy();
    return subjectServiceImpl.addSubject(subject);
  }
  
  public com.model.Subject[] getAllSubjects() throws java.rmi.RemoteException{
    if (subjectServiceImpl == null)
      _initSubjectServiceImplProxy();
    return subjectServiceImpl.getAllSubjects();
  }
  
  public boolean deleteSubject(int id) throws java.rmi.RemoteException{
    if (subjectServiceImpl == null)
      _initSubjectServiceImplProxy();
    return subjectServiceImpl.deleteSubject(id);
  }
  
  public com.model.Subject getSubject(int id) throws java.rmi.RemoteException{
    if (subjectServiceImpl == null)
      _initSubjectServiceImplProxy();
    return subjectServiceImpl.getSubject(id);
  }
  
  
}