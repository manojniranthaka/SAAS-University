package com.service;

public class LibraryServiceImplProxy implements com.service.LibraryServiceImpl {
  private String _endpoint = null;
  private com.service.LibraryServiceImpl libraryServiceImpl = null;
  
  public LibraryServiceImplProxy() {
    _initLibraryServiceImplProxy();
  }
  
  public LibraryServiceImplProxy(String endpoint) {
    _endpoint = endpoint;
    _initLibraryServiceImplProxy();
  }
  
  private void _initLibraryServiceImplProxy() {
    try {
      libraryServiceImpl = (new com.service.LibraryServiceImplServiceLocator()).getLibraryServiceImpl();
      if (libraryServiceImpl != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)libraryServiceImpl)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)libraryServiceImpl)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (libraryServiceImpl != null)
      ((javax.xml.rpc.Stub)libraryServiceImpl)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.service.LibraryServiceImpl getLibraryServiceImpl() {
    if (libraryServiceImpl == null)
      _initLibraryServiceImplProxy();
    return libraryServiceImpl;
  }
  
  public com.model.Library getLibrary(int id) throws java.rmi.RemoteException{
    if (libraryServiceImpl == null)
      _initLibraryServiceImplProxy();
    return libraryServiceImpl.getLibrary(id);
  }
  
  public boolean addLibrary(com.model.Library library) throws java.rmi.RemoteException{
    if (libraryServiceImpl == null)
      _initLibraryServiceImplProxy();
    return libraryServiceImpl.addLibrary(library);
  }
  
  public boolean deleteLibrary(int id) throws java.rmi.RemoteException{
    if (libraryServiceImpl == null)
      _initLibraryServiceImplProxy();
    return libraryServiceImpl.deleteLibrary(id);
  }
  
  public com.model.Library[] getAllLibraries() throws java.rmi.RemoteException{
    if (libraryServiceImpl == null)
      _initLibraryServiceImplProxy();
    return libraryServiceImpl.getAllLibraries();
  }
  
  
}