/**
 * ParkingServiceImpl.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.service;

public interface ParkingServiceImpl extends java.rmi.Remote {
    public boolean addParking(com.model.Parking parking) throws java.rmi.RemoteException;
    public boolean deleteParking(int id) throws java.rmi.RemoteException;
    public com.model.Parking getParking(int id) throws java.rmi.RemoteException;
    public com.model.Parking[] getAllParkings() throws java.rmi.RemoteException;
}
