/**
 * LibraryServiceImpl.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.service;

public interface LibraryServiceImpl extends java.rmi.Remote {
    public com.model.Library getLibrary(int id) throws java.rmi.RemoteException;
    public boolean addLibrary(com.model.Library library) throws java.rmi.RemoteException;
    public boolean deleteLibrary(int id) throws java.rmi.RemoteException;
    public com.model.Library[] getAllLibraries() throws java.rmi.RemoteException;
}
