package com.model;

import java.io.Serializable;

public class Student implements Serializable {

	private static final long serialVersionUID = -5577579081118070434L;
	
	private String name;
	private String faculty;
	private int year;
	private int semester;
	private int telephone;
	private int id;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public String getFaculty() {
		return faculty;
	}

	public void setFaculty(String faculty) {
		this.faculty = faculty;
	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}


	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public int getSemester() {
		return semester;
	}

	public void setSemester(int semester) {
		this.semester = semester;
	}
	
	public int getTelephone() {
		return telephone;
	}

	public void setTelephone(int telephone) {
		this.telephone = telephone;
	}
	
	@Override
	public String toString(){
		return id+"::"+year+"::"+semester+"::"+name+"::"+faculty+"::"+telephone;
	}

}









