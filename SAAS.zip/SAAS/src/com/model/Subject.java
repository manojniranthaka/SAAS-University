package com.model;

import java.io.Serializable;

public class Subject implements Serializable {

	private static final long serialVersionUID = -5577579081118070434L;
	
	private String name;
	private String faculty;
	private String subject;
	private int id;
	private int subjectID;

	public String getName() {
		return name;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public int getSubjectID() {
		return subjectID;
	}

	public void setSubjectID(int subjectID) {
		this.subjectID = subjectID;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public String getFaculty() {
		return faculty;
	}

	public void setFaculty(String faculty) {
		this.faculty = faculty;
	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	
	@Override
	public String toString(){
		return id+"::"+faculty+"::"+name+"::"+subject+"::"+subjectID;
	}

}









