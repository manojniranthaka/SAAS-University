package com.model;

import java.io.Serializable;

public class Parking implements Serializable  {

	private static final long serialVersionUID = -5577579081118070434L;
	
	private String vehicle_type;
	private String vehicle_num;
	private String faculty;
	private int year;
	private int slot_price;
	private int telephone;
	private int id;
	
	public String getVehicle_type() {
		return vehicle_type;
	}
	public void setVehicle_type(String vehicle_type) {
		this.vehicle_type = vehicle_type;
	}
	public String getVehicle_num() {
		return vehicle_num;
	}
	public void setVehicle_num(String vehicle_num) {
		this.vehicle_num = vehicle_num;
	}
	public String getFaculty() {
		return faculty;
	}
	public void setFaculty(String faculty) {
		this.faculty = faculty;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public int getSlot_price() {
		return slot_price;
	}
	public void setSlot_price(int slot_price) {
		this.slot_price = slot_price;
	}
	public int getTelephone() {
		return telephone;
	}
	public void setTelephone(int telephone) {
		this.telephone = telephone;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	@Override
	public String toString(){
		return id+"::"+year+"::"+vehicle_type+"::"+vehicle_num+"::"+faculty+"::"+telephone+"::"+slot_price;
	}


}
