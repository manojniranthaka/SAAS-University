package com.service;

import com.model.*;
public interface StudentService {

	public boolean addStudent(Student student);
	
	public boolean deleteStudent(int id);
	
	public Student getStudent(int id);
	
	public Student[] getAllStudents();
	

	
}
