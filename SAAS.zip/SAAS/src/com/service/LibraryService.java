package com.service;

import com.model.*;

public interface LibraryService {

public boolean addLibrary(Library library);
	
	public boolean deleteLibrary(int id);
	
	public Library getLibrary(int id);
	
	public Library[] getAllLibraries();
	
	
}
