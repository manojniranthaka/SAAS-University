package com.service;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import com.model.*;

public class SubjectServiceImpl implements SubjectService {

	private static Map<Integer,Subject> subjects = new HashMap<Integer,Subject>();
	
	@Override
	public boolean addSubject(Subject subject) {
		if(subjects.get(subject.getId()) != null) return false;
		subjects.put(subject.getId(), subject);
		return true;
	}

	@Override
	public boolean deleteSubject(int id) {
		if(subjects.get(id) == null) return false;
		subjects.remove(id);
		return true;
	}

	@Override
	public Subject getSubject(int id) {
		return subjects.get(id);
	}

	@Override
	public Subject[] getAllSubjects() {
		Set<Integer> ids = subjects.keySet();
		Subject[] subject = new Subject[ids.size()];
		int i=0;
		for(Integer id : ids){
			subject[i] = subjects.get(id);
			i++;
		}
		return subject;
	}

}
