package com.service;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import com.model.*;


public class ServiceImpl implements Service {

	private static Map<Integer,Student> students = new HashMap<Integer,Student>();
	
	@Override
	public boolean addStudent(Student student) {
		if(students.get(student.getId()) != null) return false;
		students.put(student.getId(), student);
		return true;
	}

	@Override
	public boolean deleteStudent(int id) {
		if(students.get(id) == null) return false;
		students.remove(id);
		return true;
	}

	@Override
	public Student getStudent(int id) {
		return students.get(id);
	}

	@Override
	public Student[] getAllStudents() {
		Set<Integer> ids = students.keySet();
		Student[] student = new Student[ids.size()];
		int i=0;
		for(Integer id : ids){
			student[i] = students.get(id);
			i++;
		}
		return student;
	}
	
private static Map<Integer,Parking> parkings = new HashMap<Integer,Parking>();
	
	@Override
	public boolean addParking(Parking parking) {
		if(parkings.get(parking.getId()) != null) return false;
		parkings.put(parking.getId(), parking);
		return true;
	}

	@Override
	public boolean deleteParking(int id) {
		if(parkings.get(id) == null) return false;
		parkings.remove(id);
		return true;
	}

	@Override
	public Parking getParking(int id) {
		return parkings.get(id);
	}

	@Override
	public Parking[] getAllParkings() {
		Set<Integer> ids = parkings.keySet();
		Parking[] parking = new Parking[ids.size()];
		int i=0;
		for(Integer id : ids){
			parking[i] = parkings.get(id);
			i++;
		}
		return parking;
	}

	
private static Map<Integer,Subject> subjects = new HashMap<Integer,Subject>();
	
	@Override
	public boolean addSubject(Subject subject) {
		if(subjects.get(subject.getId()) != null) return false;
		subjects.put(subject.getId(), subject);
		return true;
	}

	@Override
	public boolean deleteSubject(int id) {
		if(subjects.get(id) == null) return false;
		subjects.remove(id);
		return true;
	}

	@Override
	public Subject getSubject(int id) {
		return subjects.get(id);
	}

	@Override
	public Subject[] getAllSubjects() {
		Set<Integer> ids = subjects.keySet();
		Subject[] subject = new Subject[ids.size()];
		int i=0;
		for(Integer id : ids){
			subject[i] = subjects.get(id);
			i++;
		}
		return subject;
	}


private static Map<Integer,Library> libraries = new HashMap<Integer,Library>();
	
	@Override
	public boolean addLibrary(Library library) {
		if(libraries.get(library.getId()) != null) return false;
		libraries.put(library.getId(), library);
		return true;
	}

	@Override
	public boolean deleteLibrary(int id) {
		if(libraries.get(id) == null) return false;
		libraries.remove(id);
		return true;
	}

	@Override
	public Library getLibrary(int id) {
		return libraries.get(id);
	}

	@Override
	public Library[] getAllLibraries() {
		Set<Integer> ids = libraries.keySet();
		Library[] library = new Library[ids.size()];
		int i=0;
		for(Integer id : ids){
			library[i] = libraries.get(id);
			i++;
		}
		return library;
	}

}
