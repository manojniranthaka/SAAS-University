package com.service;

import com.model.*;

public interface ParkingService {

public boolean addParking(Parking parking);
	
	public boolean deleteParking (int id);
	
	public Parking getParking(int id);
	
	public Parking[] getAllParkings();
	
}
