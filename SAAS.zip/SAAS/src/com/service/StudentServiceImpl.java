package com.service;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import com.model.*;


public class StudentServiceImpl implements StudentService {

	private static Map<Integer,Student> students = new HashMap<Integer,Student>();
	
	@Override
	public boolean addStudent(Student student) {
		if(students.get(student.getId()) != null) return false;
		students.put(student.getId(), student);
		return true;
	}

	@Override
	public boolean deleteStudent(int id) {
		if(students.get(id) == null) return false;
		students.remove(id);
		return true;
	}

	@Override
	public Student getStudent(int id) {
		return students.get(id);
	}

	@Override
	public Student[] getAllStudents() {
		Set<Integer> ids = students.keySet();
		Student[] student = new Student[ids.size()];
		int i=0;
		for(Integer id : ids){
			student[i] = students.get(id);
			i++;
		}
		return student;
	}

}
