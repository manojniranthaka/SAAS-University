package com.service;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import com.model.*;


public class ParkingServiceImpl implements ParkingService {

private static Map<Integer,Parking> parkings = new HashMap<Integer,Parking>();
	
	@Override
	public boolean addParking(Parking parking) {
		if(parkings.get(parking.getId()) != null) return false;
		parkings.put(parking.getId(), parking);
		return true;
	}

	@Override
	public boolean deleteParking(int id) {
		if(parkings.get(id) == null) return false;
		parkings.remove(id);
		return true;
	}

	@Override
	public Parking getParking(int id) {
		return parkings.get(id);
	}

	@Override
	public Parking[] getAllParkings() {
		Set<Integer> ids = parkings.keySet();
		Parking[] parking = new Parking[ids.size()];
		int i=0;
		for(Integer id : ids){
			parking[i] = parkings.get(id);
			i++;
		}
		return parking;
	}

}
