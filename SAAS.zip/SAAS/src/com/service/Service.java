package com.service;

import com.model.Library;
import com.model.Parking;
import com.model.Student;
import com.model.Subject;

public interface Service {

	boolean addStudent(Student student);

	boolean deleteStudent(int id);

	Student getStudent(int id);

	Student[] getAllStudents();

	boolean addParking(Parking parking);

	boolean deleteParking(int id);

	Parking getParking(int id);

	Parking[] getAllParkings();

	boolean addSubject(Subject subject);

	boolean deleteSubject(int id);

	Subject getSubject(int id);

	Subject[] getAllSubjects();

	boolean addLibrary(Library library);

	boolean deleteLibrary(int id);

	Library getLibrary(int id);

	Library[] getAllLibraries();

}
