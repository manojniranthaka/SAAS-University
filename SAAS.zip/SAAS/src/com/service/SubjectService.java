package com.service;

import com.model.*;

public interface SubjectService {

	public boolean addSubject(Subject subject);
	
	public boolean deleteSubject(int id);
	
	public Subject getSubject(int id);
	
	public Subject[] getAllSubjects();
	

	
}
