package com.service;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import com.model.*;

public class LibraryServiceImpl implements LibraryService{
	
	
private static Map<Integer,Library> libraries = new HashMap<Integer,Library>();
	
	@Override
	public boolean addLibrary(Library library) {
		if(libraries.get(library.getId()) != null) return false;
		libraries.put(library.getId(), library);
		return true;
	}

	@Override
	public boolean deleteLibrary(int id) {
		if(libraries.get(id) == null) return false;
		libraries.remove(id);
		return true;
	}

	@Override
	public Library getLibrary(int id) {
		return libraries.get(id);
	}

	@Override
	public Library[] getAllLibraries() {
		Set<Integer> ids = libraries.keySet();
		Library[] library = new Library[ids.size()];
		int i=0;
		for(Integer id : ids){
			library[i] = libraries.get(id);
			i++;
		}
		return library;
	}

}
